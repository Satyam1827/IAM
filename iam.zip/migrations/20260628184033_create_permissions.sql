CREATE TABLE permissions (
    id UUID PRIMARY KEY
        DEFAULT gen_random_uuid(),

    name TEXT NOT NULL UNIQUE,

    description TEXT,

    created_at TIMESTAMPTZ
        NOT NULL
        DEFAULT NOW()
);