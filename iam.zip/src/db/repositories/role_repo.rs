use anyhow::Result;
use sqlx::{
    Postgres,
    Transaction,
};
use uuid::Uuid;

use crate::db::models::role::Role;

pub async fn create_tx(
    tx: &mut Transaction<'_, Postgres>,
    organization_id: Uuid,
    name: &str,
    description: Option<&str>,
) -> Result<Role> {
    let role =
        sqlx::query_as::<_, Role>(
            r#"
            INSERT INTO roles (
                organization_id,
                name,
                description
            )
            VALUES ($1,$2,$3)
            RETURNING *
            "#
        )
        .bind(organization_id)
        .bind(name)
        .bind(description)
        .fetch_one(tx.as_mut())
        .await?;

    Ok(role)
}